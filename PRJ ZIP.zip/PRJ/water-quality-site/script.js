// Page logic. Needs data.js loaded first (defines M).
(function(){
const NAMES=['pH','Hardness','Solids','Chloramines','Sulfate','Conductivity','Organic carbon','Trihalomethanes','Turbidity'];
const UNITS=['','mg/L','ppm','ppm','mg/L','µS/cm','ppm','µg/L','NTU'];
const $=id=>document.getElementById(id);
const f1=x=>x.toLocaleString('en-US',{maximumFractionDigits:1});
const f2=x=>x.toFixed(2);
const pct=x=>(x*100).toFixed(2)+'%';
const nf=x=>x>=1000?Math.round(x).toLocaleString('en-US'):x.toFixed(2);

/* hero chart */
(function(){
  const h=$('heroPlot'),H=210-34; const a=M.acc;
  const mk=(c,v)=>`<div class="bar ${c}"><div class="v">${(v*100).toFixed(2)}%</div><div class="fill" style="height:${v*H}px"></div></div>`;
  h.innerHTML=mk('lr',a[0])+mk('dt',a[1])+`<div class="base" style="bottom:${a[0]*H}px"><span>always “Not Potable” 62.80%</span></div>`;
})();

/* dataset */
(function(){
  const [n0,n1]=M.counts,N=M.n;
  $('split').innerHTML=`<div class="n" style="width:${n0/N*100}%">${n0.toLocaleString()} Not Potable</div><div class="p" style="width:${n1/N*100}%">${n1.toLocaleString()}</div>`;
  const rows=Object.entries(M.missing).map(([k,v])=>`<tr><td>${k==='ph'?'pH':k}</td><td class="m">${v}</td><td class="m">${(v/N*100).toFixed(1)}%</td></tr>`).join('');
  $('missTable').innerHTML=`<tr><th>Column</th><th>Missing</th><th>Of rows</th></tr>${rows}`;
  const fr=M.cols.map((c,i)=>{const s=M.stats[c];return `<tr><td>${NAMES[i]}${UNITS[i]?` <span class="label" style="text-transform:none;letter-spacing:0">${UNITS[i]}</span>`:''}</td><td class="m">${nf(s.min)}</td><td class="m">${nf(s.mean)}</td><td class="m">${nf(s.max)}</td></tr>`}).join('');
  $('featTable').innerHTML=`<tr><th>Feature</th><th>Min</th><th>Mean</th><th>Max</th></tr>${fr}`;
})();

/* models facts */
(function(){
  $('lrFacts').innerHTML=`<dt>Input</dt><dd>9 scaled features</dd><dt>Accuracy</dt><dd>${pct(M.acc[0])}</dd>`;
  $('dtFacts').innerHTML=`<dt>Input</dt><dd>9 original features</dd><dt>Full tree</dt><dd>depth ${M.dt_depth}, ${M.dt_leaves} leaves</dd><dt>Accuracy</dt><dd>${pct(M.acc[1])}</dd>`;
})();

/* confusion matrices + reports */
function cm(id,m){
  const rt=[m[0][0]+m[0][1],m[1][0]+m[1][1]];
  const cell=(v,r,ok)=>`<div class="c ${ok?'ok':'no'}" style="--p:${v/rt[r]}">${v}<small>${(v/rt[r]*100).toFixed(0)}% of row</small></div>`;
  $(id).innerHTML=`<div class="h"></div><div class="h">Pred. Not Potable</div><div class="h">Pred. Potable</div>
  <div class="h r">Actual Not Potable</div>${cell(m[0][0],0,1)}${cell(m[0][1],0,0)}
  <div class="h r">Actual Potable</div>${cell(m[1][0],1,0)}${cell(m[1][1],1,1)}`;
}
function rep(id,r){
  const row=(n,k)=>`<tr><td>${n}</td><td class="m">${f2(r[k].precision)}</td><td class="m">${f2(r[k].recall)}</td><td class="m">${f2(r[k]['f1-score'])}</td><td class="m">${r[k].support}</td></tr>`;
  $(id).innerHTML=`<tr><th>Class</th><th>Precision</th><th>Recall</th><th>F1</th><th>Support</th></tr>${row('Not Potable','0')}${row('Potable','1')}`;
}
cm('cmLR',M.cm_lr);cm('cmDT',M.cm_dt);rep('repLR',M.rep_lr);rep('repDT',M.rep_dt);

/* importance */
(function(){
  const arr=M.cols.map((c,i)=>[NAMES[i],M.imp[c]]).sort((a,b)=>b[1]-a[1]);
  const mx=arr[0][1];
  $('imp').innerHTML=arr.map(([n,v])=>`<div class="r"><span>${n}</span><div class="t"><i style="width:${v/mx*100}%"></i></div><span class="p">${(v*100).toFixed(1)}%</span></div>`).join('');
})();

/* models in JS */
function lrPredict(x){
  const L=M.lr;let s=L.b;
  for(let i=0;i<x.length;i++)s+=L.coef[i]*(x[i]-L.mean[i])/L.scale[i];
  const p=1/(1+Math.exp(-s));return {p,y:p>=0.5?1:0};
}
function dtPredict(x){
  const T=M.dt;let n=0,d=0;
  while(T.l[n]!==-1){n=x[T.f[n]]<=T.t[n]?T.l[n]:T.r[n];d++}
  return {y:T.v[n],depth:d};
}

/* predictor */
(function(){
  const presets=[
    ['Slide sample',[7,200,20000,6,200,350,9,100,5]],
    ['Notebook sample',[7,200,20000,7,330,400,15,60,4]],
    ['Dataset average',M.cols.map(c=>M.stats[c].mean)]
  ];
  let vals=presets[0][1].slice();
  const inp=$('inputs');
  inp.innerHTML=M.cols.map((c,i)=>{const s=M.stats[c];
    return `<div class="in-row"><label for="n${i}">${NAMES[i]}${UNITS[i]?`<small>${UNITS[i]}</small>`:''}</label>
    <input type="number" id="n${i}" step="any" aria-label="${NAMES[i]} value">
    <input type="range" id="r${i}" min="${s.min}" max="${s.max}" step="${(s.max-s.min)/1000}" aria-label="${NAMES[i]} slider"></div>`}).join('');
  const sync=()=>{M.cols.forEach((c,i)=>{$('r'+i).value=vals[i];const n=$('n'+i);if(document.activeElement!==n)n.value=+(+vals[i]).toFixed(3)})};
  const out=()=>{
    const a=lrPredict(vals),b=dtPredict(vals);
    const v=(id,name,color,y,sub,extra)=>{const el=$(id);el.className='verdict '+(y?'good':'bad');
      el.innerHTML=`<div class="who"><span class="dot" style="width:10px;height:10px;border-radius:2px;background:${color}"></span><b>${name}</b></div><div class="big">${y?'POTABLE':'NOT POTABLE'}</div>${extra||''}<div class="sub">${sub}</div>`};
    v('vLR','Logistic Regression','var(--accent)',a.y,`probability of potable: ${(a.p*100).toFixed(1)}% (threshold 50%)`,`<div class="meter" aria-hidden="true"><i style="width:${a.p*100}%"></i><b></b></div>`);
    v('vDT','Decision Tree','var(--dt)',b.y,`reached a leaf after ${b.depth} splits`);
  };
  const setPressed=k=>[...$('presets').children].forEach((b,j)=>b.setAttribute('aria-pressed',j===k));
  $('presets').innerHTML=presets.map((p,j)=>`<button class="chip" type="button" data-k="${j}" aria-pressed="${j===0}">${p[0]}</button>`).join('');
  $('presets').addEventListener('click',e=>{const b=e.target.closest('button');if(!b)return;const k=+b.dataset.k;vals=presets[k][1].slice();setPressed(k);sync();out()});
  M.cols.forEach((c,i)=>{
    $('r'+i).addEventListener('input',e=>{vals[i]=+e.target.value;setPressed(-1);sync();out()});
    $('n'+i).addEventListener('input',e=>{const v=parseFloat(e.target.value);if(!isNaN(v)){vals[i]=v;$('r'+i).value=v;setPressed(-1);out()}});
  });
  sync();out();
})();

/* depth-3 tree */
(function(){
  const T=M.dt3,W=156,H=60,GX=14,GY=48,PAD=8;
  const pos={};let leafI=0;
  (function lay(n,d){
    if(T.l[n]===-1){pos[n]={x:leafI++*(W+GX),y:d*(H+GY)};return}
    lay(T.l[n],d+1);lay(T.r[n],d+1);
    pos[n]={x:(pos[T.l[n]].x+pos[T.r[n]].x)/2,y:d*(H+GY)};
  })(0,0);
  const width=leafI*(W+GX)-GX+PAD*2,height=3*(H+GY)+H+PAD*2;
  let lines='',boxes='';
  const walk=n=>{
    const p=pos[n],[a,b]=T.val[n],tot=a+b,pb=b/tot;
    const col=b>a?'var(--good)':'var(--bad)',pur=Math.abs(pb-.5)*2;
    const fill=`color-mix(in srgb,${col} ${Math.round(18+pur*70)}%,var(--surface))`;
    const x=p.x+PAD,y=p.y+PAD;
    let t1;
    if(T.l[n]===-1)t1=b>a?'Potable':'Not Potable';
    else{const nm=NAMES[T.f[n]];t1=`${nm} ≤ ${nf(T.t[n])}`}
    boxes+=`<g><rect x="${x}" y="${y}" width="${W}" height="${H}" rx="6" fill="${fill}" stroke="var(--line)"/>
      <text x="${x+W/2}" y="${y+24}" text-anchor="middle" font-size="12.5" font-weight="500">${t1}</text>
      <text x="${x+W/2}" y="${y+42}" text-anchor="middle" font-size="11" opacity=".75">n=${tot.toLocaleString()} · ${Math.round(a)} / ${Math.round(b)}</text></g>`;
    if(T.l[n]!==-1){
      [T.l[n],T.r[n]].forEach((c,k)=>{const q=pos[c];
        lines+=`<path d="M${x+W/2},${y+H} C${x+W/2},${y+H+GY/2} ${q.x+PAD+W/2},${q.y+PAD-GY/2} ${q.x+PAD+W/2},${q.y+PAD}" fill="none" stroke="var(--muted)" stroke-width="1.2"/>
        <text x="${(x+W/2+q.x+PAD+W/2)/2+(k?10:-10)}" y="${y+H+GY/2+4}" text-anchor="${k?'start':'end'}" font-size="10" fill="var(--muted)" style="fill:var(--muted)">${k?'false':'true'}</text>`;
        walk(c)});
    }
  };
  walk(0);
  const svg=$('treeSvg');svg.setAttribute('width',width);svg.setAttribute('height',height);svg.setAttribute('viewBox',`0 0 ${width} ${height}`);
  svg.innerHTML=lines+boxes;
})();
})();
